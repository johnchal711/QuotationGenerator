let userimput;
let generatorimput;


//  Wine Review Generator,The world's definitive database of wine reviews. 
//The search interface isn't super-convenient, but keep hitting the button and you should eventually 
//get to the particular wine that you're interested in. Your tastes may differ from the reviewer's.

let myquotea = 
[
[   'The 2004 Cabernet Sauvignon from Gonzales Winery ',
    'Montecello Winery',
    'Skunk Meadows Vineyards ',
    'Champs de Martine',
    'The 1993 Pinot Grigio',
    
],
[   ' fuses indigestible musk flavors with',
    ' incorporates uninhibited vinyl undertones and',
    ' mixes libido-boosting velvet essences and',
    ' intertwines grimy vodka elements and',
    ' from Fiat Bros Winery coalesces brazen cactus midtones with',
   

],
[
    ' a krispy pheremone aroma.',
    ' a fervent almond perfume in their 1999 Bordeaux.',
    ' a rough rasberry flavor in their 1998 Pinot Noir.',
    ' a torrid Kandy Korn flavor in their 2006 Zinfandel.',
    ' a watery oatmeal aftertaste.',
    ' a embittered macademia nut essence.',
    ' a ambitious lavender bouquet',
    ' a mildewed strawberry perfume.',

],
];






// Button Control





function getQuote(button) {
    generatorimput = button.value;
    //The getElementById() method returns the element that has the ID attribute with the specified value.
    //This method is one of the most common methods in the HTML DOM, and is used almost every time you want to manipulate, or get info from, an element on your document.
    //Returns null if no elements with the specified ID exists.
    //An ID should be unique within a page. However, if more than one element with the specified ID exists, the getElementById() method returns the first element in the source code.
    document.getElementById('quote').innerHTML = "";
    //The innerHTML property sets or returns the HTML content (inner HTML) of an element.
      Maker(myquotea);


   };


//Generator Process

function Maker(arr) {
    //The floor() method rounds a number DOWNWARDS to the nearest integer, and returns the result.
    //If the passed argument is an integer, the value will not be rounded.
    //Round a number downward to its nearest integer Math.floor(1.6);

    //Math.random() returns a random number between 0 (inclusive),  and 1 (exclusive):,always returns a number lower than 1.

    myquote = "";
    myquote = arr[0][Math.floor(Math.random()*arr[0].length)];

    //The += assignment operator can also be used to add (concatenate) strings:
    myquote += arr[1][Math.floor(Math.random()*arr[1].length)];

    if(arr.length == 3) {
        myquote += arr[2][Math.floor(Math.random()*arr[2].length)];
    }
    printInside(myquote);
};


function printInside(text) {
    let newParagraph = document.createElement('p');
    newParagraph.className = "new-paragraph";
    newParagraph.innerText = text;
    document.getElementById('quote').appendChild(newParagraph);
       
};





       










